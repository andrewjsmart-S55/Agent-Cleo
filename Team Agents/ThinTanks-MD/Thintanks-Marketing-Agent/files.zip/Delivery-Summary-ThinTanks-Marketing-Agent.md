# ThinTanks Marketing Agent Skill - Delivery Summary

## What You've Received

I've created a comprehensive Claude Skill that transforms Claude into your dedicated marketing and content creation expert for ThinTanks.co.uk. This isn't just a simple prompt - it's a fully-structured, professional-grade skill following Anthropic's best practices for skill development.

## Files Delivered

### 1. **thintanks-marketing-agent.zip** (Main Deliverable)
This is your complete, ready-to-install Claude Skill containing:

**Core Skill File:**
- `SKILL.md` - 500+ lines of detailed instructions, workflows, and guidelines

**Reference Files (4 comprehensive documents):**
- `buyer-personas.md` - Detailed profiles of all 6 target personas with pain points, motivations, and content preferences
- `content-strategy-seo.md` - Complete SEO strategy, keyword targets, content mix requirements, and quality checklists
- `social-media-guidelines.md` - Platform-specific strategies for Instagram, LinkedIn, and X with templates and best practices
- `content-sources.md` - Monitoring sources, competitor tracking, and inspiration resources

**Total Content:** Over 15,000 words of strategic guidance and operational instructions

### 2. **ThinTanks-Marketing-Agent-Quick-Start-Guide.md**
A user-friendly guide that explains:
- What the skill does
- How to install it
- How to use it effectively
- Example prompts to get started
- Tips for best results
- Understanding the 6 buyer personas
- Key metrics to track

### 3. **Sample-Blog-Post-ThinTanks.md**
A complete example showing exactly what the skill produces:
- 2,400-word SEO-optimized blog post
- Targeting "Passionate Gardener" persona
- Complete with meta description, keywords, and structure
- AI image generation prompt
- Full social media package for Instagram, LinkedIn, and X
- Internal notes on content strategy

## Key Features & Capabilities

### Content Creation
✅ **5 blogs per week** - Each 1750-2500 words, SEO-optimized, targeting specific personas
✅ **Social media packages** - Instagram, LinkedIn, and X content for every blog
✅ **AI image generation** - Hero image prompts for each post
✅ **Squarespace formatting** - Ready to paste into your blogging platform

### Research & Monitoring
✅ **Daily monitoring routine** - Checks ThinTanks international sites, water companies, and gardening sources
✅ **Competitor tracking** - Monitors main competitors identified in your SEO analysis
✅ **Trend identification** - Spots timely opportunities for reactive content
✅ **Web search integration** - Uses Claude's search tools for current information

### Monthly Deliverables
✅ **UK gardeners to-do list** - Seasonal task list with ThinTanks integration
✅ **Newsletter summary** - Monthly blog roundup formatted for email

### Strategic Intelligence
✅ **References your SEO analysis** - Knows your competitive position and keyword opportunities
✅ **Understands water companies** - Has your list of UK/Ireland water companies to monitor
✅ **Persona-balanced content** - Ensures all 6 buyer types are covered weekly
✅ **Content mix optimization** - Maintains 40% educational, 30% seasonal, 15% case studies, etc.

## How It Works

The skill uses Anthropic's "progressive disclosure" design pattern:

1. **Metadata** (always loaded) - Tells Claude when to activate the skill
2. **Main SKILL.md** (loaded when needed) - Core workflows and instructions
3. **Reference files** (loaded on-demand) - Detailed guidance Claude reads as needed

This efficient design means Claude only loads what it needs, keeping context usage optimal while having access to comprehensive guidance.

## Strategic Approach

The skill is designed around your stated goal: **Sell 1,000 ThinTanks in 12 months**

Every element supports this through:

### SEO Strategy
- Targets high-value keywords from your competitive analysis
- Addresses keyword gaps (capacity-based searches, technical terms)
- Builds on your strengths (thin/slimline positioning)
- Creates topical authority through consistent, quality content

### Persona Targeting
- Each persona has distinct pain points and content preferences
- B2C personas (Gardener) focus on DIY and savings
- B2B personas (Architects, Developers) focus on specifications and ROI
- All personas receive relevant content weekly

### Multi-Channel Approach
- Blogs drive organic search traffic and establish authority
- Instagram builds community and visual appeal
- LinkedIn reaches professional audiences
- X enables real-time engagement and news response
- Email newsletter maintains customer relationships

### Content Mix
- Educational content (40%) - Builds trust and demonstrates expertise
- Seasonal content (30%) - Captures timely search traffic
- Case studies (15%) - Provides social proof
- Industry news (10%) - Shows thought leadership
- Product updates (5%) - Direct conversion opportunities

## Quality Controls Built In

The skill includes comprehensive quality checklists for:

**Blog Posts:**
- Word count verification (1750-2500)
- Keyword density and placement
- Meta description optimization
- Internal and external linking
- Readability scoring (Flesch 60-70)
- British English spelling
- Fact verification with sources

**Social Media:**
- Platform-specific character limits
- Hashtag research and relevance
- Image specification requirements
- CTA effectiveness
- Brand voice consistency
- Engagement hooks

## Integration with Your Project Files

The skill automatically references two files from your project:

1. **Major_Water_Companies_in_the_UK_and_Ireland.md**
   - Used for monitoring regional water news
   - Identifies hosepipe ban opportunities
   - Enables location-specific content

2. **ThinTanks.co.uk SEO Competitive Analysis Dashboard.html**
   - Informs keyword targeting decisions
   - Identifies content gap opportunities
   - Guides competitive positioning

## Installation Instructions

1. Download `thintanks-marketing-agent.zip`
2. In your Claude project, go to Settings → Skills
3. Click "Upload Skill" and select the zip file
4. The skill activates automatically when you ask for ThinTanks content

## Getting Started

**First conversation with the skill:**
```
"I'd like to start using the ThinTanks marketing agent. Can you run today's monitoring routine and suggest a blog topic for this week?"
```

Claude will:
1. Read all reference files to understand the strategy
2. Check ThinTanks international sites for updates
3. Monitor UK water industry news
4. Review gardening sources
5. Suggest timely, relevant blog topics
6. Note which personas still need coverage this week

**For daily blog creation:**
```
"Create today's blog post for ThinTanks targeting [persona name or general]"
```

**For monthly deliverables:**
```
"Create the November gardening to-do list for UK gardeners"
"Create the October newsletter summary of our blog posts"
```

## Why This Approach Works

### Professional Skill Structure
- Follows Anthropic's official skill creation guidelines
- Uses proven design patterns from examples
- Implements progressive disclosure for efficiency
- Includes comprehensive reference materials

### Strategic Depth
- Not just "write a blog" - comprehensive content marketing strategy
- Understands buyer psychology and persona targeting
- Balances multiple content types and channels
- Integrates SEO, social media, and email marketing

### Practical Execution
- Clear workflows for daily, weekly, and monthly tasks
- Specific templates and examples
- Quality control checklists
- Real-world oriented (British English, UK seasons, local events)

### Scalable & Adaptable
- Works whether you create 1 blog or 5 per week
- Can adjust focus as needed
- Learns from your feedback
- Grows with your business

## Expected Outcomes

With consistent use of this skill over 12 months, you can expect:

**Content Volume:**
- 260 SEO-optimized blog posts (5/week × 52 weeks)
- 780+ social media posts across three platforms
- 12 monthly gardening to-do lists
- 12 newsletter summaries
- Thousands of pieces of supporting content

**SEO Impact:**
- Improved rankings for target keywords
- Increased organic traffic to thintanks.co.uk
- Better visibility in competitive searches
- Topical authority in rainwater harvesting space

**Audience Building:**
- Engaged following across social platforms
- Email list growth through newsletter
- Community of advocates for ThinTanks
- Cross-channel audience reach

**Business Results:**
- Qualified leads from blog CTAs
- Direct inquiries from social media
- Quote requests from professional personas
- Progress toward 1,000 unit sales goal

## Support & Iteration

As you use the skill:
- **Provide feedback** - Tell Claude what's working and what needs adjustment
- **Share results** - Let Claude know which content performs best
- **Request changes** - The skill can adapt to your evolving needs
- **Ask questions** - Claude can explain any aspect of the strategy

The skill is designed to learn and improve based on real-world performance.

## Next Steps

1. **Install the skill** in your Claude project
2. **Review the Quick Start Guide** to understand capabilities
3. **Read the Sample Blog Post** to see output quality
4. **Start with monitoring** to identify timely opportunities
5. **Create your first blog** using the skill
6. **Establish a routine** for daily monitoring and weekly content creation

## Technical Notes

**Skill Size:** Approximately 50KB (efficient, fast-loading)
**Reference Files:** 4 documents, loaded on-demand
**Dependencies:** None - uses built-in Claude capabilities
**Compatibility:** Works in any Claude project with web search enabled
**Maintenance:** No updates needed - skill is self-contained

## Questions or Issues?

If you need help:
- Ask Claude to explain any part of the skill's strategy
- Request modifications to tone, format, or approach
- Share examples of content you like for Claude to emulate
- Provide performance data to optimize the strategy

## Final Notes

This skill represents a comprehensive content marketing system specifically designed for ThinTanks.co.uk. It's not a generic template - every element is tailored to your:
- Product (space-saving rainwater tanks)
- Market (UK and Ireland)
- Goal (1,000 sales in 12 months)
- Competition (analyzed via your SEO dashboard)
- Audience (6 distinct buyer personas)

The skill embodies months of content marketing expertise distilled into an AI-powered system that works for you consistently and professionally.

**Goal:** Help you sell 1,000 ThinTanks through strategic, high-quality content marketing.

**Approach:** Persona-targeted, SEO-optimized, multi-channel content creation.

**Commitment:** 5 blogs weekly + social media + monthly resources.

You're ready to transform ThinTanks.co.uk's content marketing. Let's get started! 🎯💧