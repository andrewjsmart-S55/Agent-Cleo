# ThinTanks Marketing Agent - Quick Start Guide

## What This Skill Does

This Claude Skill transforms Claude into your dedicated marketing and content creation expert for ThinTanks.co.uk. It enables Claude to:

1. **Create 5 SEO-optimized blog posts per week** (1750-2500 words each)
2. **Generate coordinated social media content** for Instagram, LinkedIn, and X
3. **Monitor industry news and competitors** daily
4. **Produce monthly gardening to-do lists** for UK gardeners
5. **Create monthly newsletter summaries** of your best blog posts

## Installation

1. Download the `thintanks-marketing-agent.zip` file
2. In Claude, go to your Project Settings
3. Navigate to the "Skills" section
4. Click "Upload Skill" and select the zip file
5. The skill will be automatically available in your project

## How to Use

### For Daily Blog Creation

Simply ask Claude:
> "Create today's blog post for ThinTanks"

Or be more specific:
> "Create a blog post for Landscape Gardeners about water conservation in autumn"

Claude will:
- Research current trends and information
- Create a 1750-2500 word SEO-optimized blog
- Generate a hero image using AI
- Create Instagram, LinkedIn, and X social media posts
- Provide all metadata and formatting for Squarespace

### For Daily Monitoring

Ask Claude:
> "Run the daily monitoring routine for ThinTanks"

Claude will check:
- ThinTanks international sites (AU, US, NZ) for updates
- UK water company news
- David Domoney's latest content
- Trending topics and opportunities

### For Monthly Deliverables

At the end of each month, ask:
> "Create the monthly gardening to-do list for [Month]"
> "Create the monthly newsletter summary for [Month]"

## Understanding the 6 Buyer Personas

The skill creates content for these target audiences:

1. **Passionate Gardener** - Home gardening enthusiast, eco-conscious, DIY-oriented
2. **Landscape Gardener** - Professional managing multiple client properties
3. **Landscape Designer** - Design professional creating outdoor spaces
4. **Architect** - Residential architect incorporating sustainability features
5. **Property Developer** - Building residential properties at scale
6. **Chief Sustainability Officer** - Corporate sustainability leader

Each week's content should cover all 6 personas across the 5 blog posts.

## Content Strategy Overview

### Weekly Blog Mix
- **40%** Educational/How-To content
- **30%** Seasonal/Timely content
- **15%** Case Studies/Success Stories
- **10%** Industry News/Trends
- **5%** Product Updates

### Key SEO Focus Areas
- Slimline/thin water tank keywords
- Capacity-based keywords (100L, 150L, 250L, etc.)
- Rainwater harvesting
- Space-saving water storage
- UK-specific gardening and water conservation

## Important Files Included

The skill includes four comprehensive reference files:

1. **buyer-personas.md** - Detailed profiles of all 6 target personas
2. **content-strategy-seo.md** - SEO best practices and content guidelines
3. **social-media-guidelines.md** - Platform-specific posting strategies
4. **content-sources.md** - Monitoring sources and inspiration sites

## Tips for Best Results

### ✅ Do This:
- Let Claude check the daily monitoring first to identify timely topics
- Specify which persona you want to target if you have a preference
- Ask Claude to check the SEO competitive analysis for keyword opportunities
- Review and provide feedback on tone/voice to help Claude learn your preferences
- Use the monthly deliverables to maintain consistency

### ❌ Avoid This:
- Don't skip the monitoring step - timely content performs better
- Don't forget to maintain persona balance across the week
- Don't ask for content outside the 1750-2500 word range
- Don't request content that conflicts with the brand voice

## Example Prompts

**Creating Content:**
- "Create Monday's blog for ThinTanks targeting gardeners"
- "Write a blog post about hosepipe bans for property developers"
- "Create a seasonal blog for October focusing on landscape designers"

**Research & Monitoring:**
- "What's trending in UK water conservation news today?"
- "Check ThinTanks international sites for new product updates"
- "What topics should we cover this week based on current trends?"

**Monthly Content:**
- "Create the November gardening to-do list for UK gardeners"
- "Summarize October's blog posts for our newsletter"

**Social Media:**
- "Create Instagram content for the latest blog post"
- "Generate LinkedIn posts for this week's professional content"

## Customization Options

You can customize the skill's behavior by:

1. **Adjusting persona priority** - Tell Claude which personas need more focus
2. **Seasonal emphasis** - Highlight specific seasonal topics or events
3. **Geographic focus** - Emphasize specific UK regions or cities
4. **Content themes** - Request specific topic series or campaigns

## Measuring Success

Track these metrics to measure content effectiveness:
- Organic search traffic to blog posts
- Keyword rankings for target terms
- Social media engagement rates
- Email newsletter open/click rates
- Lead generation from blog CTAs

## Support & Iteration

As you use this skill:
- Provide feedback on content quality and tone
- Share what's working (and what's not)
- Request adjustments to the strategy
- The skill will adapt to your preferences over time

## Your Project Files

The skill also has access to two key project files:

1. **Major_Water_Companies_in_the_UK_and_Ireland.md** - List of water companies to monitor for news
2. **ThinTanks.co.uk SEO Competitive Analysis Dashboard.html** - Your competitive positioning and keyword opportunities

Claude will reference these automatically when creating content.

## Goal Reminder

Every piece of content created by this skill is designed to support your primary objective: **Sell 1,000 ThinTanks in the next 12 months** through strategic content marketing and SEO.

---

## Need Help?

If you need to modify the skill or have questions, you can:
- Ask Claude to explain any part of its strategy
- Request changes to tone, format, or approach
- Provide examples of content you like for Claude to emulate
- Share performance data to help optimize the strategy

Happy content creating! 🎯💧