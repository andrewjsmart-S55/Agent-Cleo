# ThinTanks Marketing Agent Skill - At a Glance

## 📦 What You're Getting

```
thintanks-marketing-agent.zip
│
├── SKILL.md (473 lines, 2,120 words)
│   └── Core skill instructions and workflows
│
└── references/
    ├── buyer-personas.md (193 lines, 792 words)
    ├── content-strategy-seo.md (201 lines, 1,115 words)
    ├── social-media-guidelines.md (448 lines, 1,400 words)
    └── content-sources.md (334 lines, 1,400 words)

TOTAL: 1,649 lines, 6,827 words of strategic guidance
```

## 🎯 Mission

**Sell 1,000 ThinTanks in 12 months** through strategic content marketing

## 💪 Core Capabilities

| Capability | Output | Frequency |
|------------|--------|-----------|
| **Blog Posts** | 1750-2500 words, SEO-optimized | 5 per week |
| **Social Media** | Instagram, LinkedIn, X content | Per blog (15x/week) |
| **Monitoring** | Industry & competitor news | Daily |
| **To-Do Lists** | UK gardeners monthly tasks | Monthly |
| **Newsletters** | Blog summary roundups | Monthly |

## 👥 Target Personas (All 6 Covered Weekly)

1. **Passionate Gardener** 🌱 - DIY enthusiast, eco-conscious
2. **Landscape Gardener** 🌿 - Professional managing client properties
3. **Landscape Designer** 🎨 - Design-focused professional
4. **Architect** 📐 - Specification-driven, sustainability-focused
5. **Property Developer** 🏗️ - Volume buyer, ROI-focused
6. **Chief Sustainability Officer** 🌍 - Corporate environmental leader

## 📊 Content Strategy Mix

```
Educational/How-To     ████████████████████░░░░░  40%
Seasonal/Timely        ███████████████░░░░░░░░░░  30%
Case Studies           ████████░░░░░░░░░░░░░░░░░  15%
Industry News          █████░░░░░░░░░░░░░░░░░░░░  10%
Product Updates        ███░░░░░░░░░░░░░░░░░░░░░░   5%
```

## 🔍 SEO Focus Areas

### Primary Keywords
- thin water tank
- slimline water tank
- space-saving water storage
- rainwater harvesting tank

### Capacity Keywords
- 100 litre water tank
- 150 litre water tank
- 250 litre water tank
- 300 litre water tank
- 1000 litre thin tank

### Long-tail Opportunities
- water tank for small gardens
- rainwater harvesting for terraced houses
- space-saving rainwater collection
- thin water tank installation

## 🌐 Multi-Platform Strategy

### Instagram (Daily)
- Visual storytelling
- Community building
- 20-30 hashtags per post
- Stories + carousel posts

### LinkedIn (3-5x/week)
- B2B thought leadership
- Professional case studies
- Technical specifications
- Industry insights

### X/Twitter (3-5x/week)
- Timely news and trends
- Quick tips and facts
- Engagement and conversation
- Thread storytelling

## 📅 Annual Output Projection

| Content Type | Weekly | Monthly | Annually |
|-------------|---------|---------|----------|
| Blog Posts | 5 | 20 | 260 |
| Instagram Posts | 7 | 28 | 364 |
| LinkedIn Posts | 4 | 16 | 208 |
| X Posts | 4 | 16 | 208 |
| To-Do Lists | - | 1 | 12 |
| Newsletters | - | 1 | 12 |
| **Total Pieces** | **20** | **82** | **1,064** |

## 🎨 Each Blog Package Includes

✅ SEO-optimized 1750-2500 word article
✅ Meta description (150-160 characters)
✅ Primary + secondary keywords
✅ 3-5 internal links
✅ 2-3 external authoritative links
✅ AI-generated hero image prompt
✅ 2-3 additional image descriptions
✅ Alt text for all images
✅ Instagram caption + Story slides + first comment
✅ LinkedIn professional post
✅ X/Twitter main tweet + optional thread
✅ Squarespace-ready formatting
✅ Content strategy notes

## 🔧 Built-in Quality Controls

### Blog Post Checklist (14 items)
- Word count verification
- Keyword optimization
- Meta description
- Link requirements
- Image specifications
- Readability scoring
- British English spelling
- Fact verification

### Social Media Checklist (8 items)
- Platform formatting
- Character limits
- Hashtag research
- Image specs
- Persona targeting
- CTA effectiveness
- Brand consistency
- Engagement hooks

### Monthly Deliverables (4 items)
- Seasonal appropriateness
- Source verification
- ThinTanks integration
- Format and scannability

## 📈 Expected Results Over 12 Months

### Content Creation
- **260 blog posts** establishing topical authority
- **780+ social posts** building community
- **12 monthly resources** nurturing email list
- **Thousands of keywords** ranked

### SEO Impact
- Improved search rankings
- Increased organic traffic
- Better keyword visibility
- Topical authority established

### Business Outcomes
- Qualified lead generation
- Professional inquiries
- Quote requests
- Progress toward 1,000 sales

## 🚀 Quick Start Commands

**Daily Monitoring:**
```
"Run today's monitoring routine for ThinTanks"
```

**Create Blog:**
```
"Create today's blog post for ThinTanks targeting [Gardener/Designer/Architect/etc]"
```

**Monthly Tasks:**
```
"Create the [Month] gardening to-do list"
"Create the [Month] newsletter summary"
```

**Strategy Questions:**
```
"What topics should we cover this week?"
"What's trending in UK water conservation?"
"Which personas need more coverage?"
```

## 🎓 Reference Materials Included

### Buyer Personas (792 words)
- Complete profiles for all 6 personas
- Pain points and motivations
- Content interests and preferences
- Platform distribution strategy
- Key messaging for each

### Content Strategy & SEO (1,115 words)
- Weekly content mix formula
- SEO keyword strategy
- On-page optimization checklist
- Title and meta description templates
- Content structure templates
- Tone and voice guidelines
- Seasonal content calendar
- Quality control checklists

### Social Media Guidelines (1,400 words)
- Platform-specific strategies
- Post format templates
- Hashtag strategies
- Best posting times (UK)
- Visual content guidelines
- Engagement best practices
- Analytics and optimization
- Compliance requirements

### Content Sources (1,400 words)
- ThinTanks international sites monitoring
- UK water company tracking
- Gardening inspiration sources
- Industry news sources
- Competitor monitoring
- Content idea generation process
- Alert setup instructions
- Quick content ideas bank

## 💡 Why This Works

### Strategic Depth
✓ Comprehensive marketing strategy, not just blog writing
✓ Understands buyer psychology and persona targeting
✓ Balances content types and channels
✓ Integrates SEO, social media, and email

### Professional Quality
✓ Follows Anthropic's skill creation best practices
✓ Uses proven design patterns
✓ Includes comprehensive reference materials
✓ Built with progressive disclosure for efficiency

### Practical Execution
✓ Clear daily, weekly, and monthly workflows
✓ Specific templates and examples
✓ Quality control systems
✓ UK-focused (spelling, seasons, events)

### Scalable System
✓ Works for 1 or 5 blogs per week
✓ Adapts to feedback and performance
✓ Learns from results
✓ Grows with your business

## 📝 Installation & Setup

1. **Download** `thintanks-marketing-agent.zip`
2. **Navigate** to your Claude Project Settings
3. **Click** "Skills" → "Upload Skill"
4. **Select** the zip file
5. **Activate** by asking for ThinTanks content

**First Use:**
The skill will automatically read all reference files to understand your complete strategy, then begin with daily monitoring.

## 🎯 Success Metrics to Track

- Organic search traffic growth
- Keyword ranking improvements
- Social media engagement rates
- Email newsletter open/click rates
- Lead generation from blog CTAs
- Quote requests from content
- Progress toward 1,000 sales goal

## 💼 Professional Features

- British English throughout
- UK seasonal calendar
- Local water company monitoring
- RHS-aligned gardening advice
- Regulatory compliance awareness
- Professional specifications for B2B personas
- Technical accuracy for architects/developers

## 🌟 Unique Advantages

**Persona Intelligence** - Understands all 6 buyer types and their distinct needs
**SEO Integration** - References your competitive analysis directly
**Multi-Channel** - Coordinates blog, Instagram, LinkedIn, and X
**Timely Content** - Daily monitoring identifies opportunities
**Quality Assurance** - Built-in checklists ensure consistency
**Brand Consistency** - Matches ThinTanks.co.uk tone and voice
**Goal-Oriented** - Every piece supports the 1,000-sales mission

---

## Ready to Transform Your Content Marketing?

Everything you need is in `thintanks-marketing-agent.zip`

**1,000 ThinTanks in 12 months starts with exceptional content. Let's begin! 🎯💧**